import React, { useEffect, useState } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../firebase";

export default function ContractsList() {
  const [contracts, setContracts] = useState([]);

  useEffect(() => {
    const fetchContracts = async () => {
      const snapshot = await getDocs(collection(db, "contracts"));
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setContracts(data);
    };
    fetchContracts();
  }, []);

  return (
    <div className="p-4 max-w-4xl mx-auto bg-white text-green-600">
      <header className="flex items-center justify-between mb-4">
        <img src="/logo.png" alt="Logo" className="h-12" />
        <h1 className="text-2xl font-bold">Contract Management</h1>
      </header>
      <h2 className="text-xl mb-4">Signed Contracts</h2>
      {contracts.length === 0 ? (
        <p>No contracts found.</p>
      ) : (
        <table className="w-full table-auto border">
          <thead>
            <tr className="bg-gray-200">
              <th className="p-2 border">Client</th>
              <th className="p-2 border">Invoice</th>
              <th className="p-2 border">Date</th>
              <th className="p-2 border">Preview</th>
            </tr>
          </thead>
          <tbody>
            {contracts.map((contract) => (
              <tr key={contract.id}>
                <td className="p-2 border">{contract.client}</td>
                <td className="p-2 border">{contract.invoice}</td>
                <td className="p-2 border">{new Date(contract.date).toLocaleString()}</td>
                <td className="p-2 border">
                  <img src={contract.image} alt="signature" className="h-20" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
