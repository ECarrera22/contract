import React, { useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { db } from "../firebase";
import { collection, addDoc, Timestamp } from "firebase/firestore";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import emailjs from "emailjs-com";

const clients = {
  "1": { name: "John Doe", email: "john@example.com" },
  "2": { name: "Jane Smith", email: "jane@example.com" },
};

export default function Contract() {
  const { clientId, invoiceId } = useParams();
  const canvasRef = useRef(null);
  const contractRef = useRef(null);
  const [signatureSaved, setSignatureSaved] = useState(false);
  let drawing = false;

  const startDrawing = (e) => {
    drawing = true;
    const ctx = canvasRef.current.getContext("2d");
    ctx.beginPath();
    ctx.moveTo(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
  };

  const draw = (e) => {
    if (!drawing) return;
    const ctx = canvasRef.current.getContext("2d");
    ctx.lineTo(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
    ctx.stroke();
  };

  const endDrawing = () => {
    drawing = false;
  };

  const saveSignature = () => {
    setSignatureSaved(true);
    alert("Signature saved!");
  };

  const exportPDF = () => {
    if (!signatureSaved) return alert("Please save the signature first.");
    html2canvas(contractRef.current).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF();
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
      pdf.save(`contract_${clients[clientId].name}_${invoiceId}.pdf`);
    });
  };

  const sendEmail = () => {
    if (!signatureSaved) return alert("Please save the signature first.");
    html2canvas(contractRef.current).then((canvas) => {
      const image = canvas.toDataURL("image/png");
      emailjs.send("service_xxx", "template_xxx", {
        to_name: clients[clientId].name,
        to_email: clients[clientId].email,
        message: `Contract for ${clients[clientId].name}, invoice #${invoiceId}`,
        image: image,
      }, "public_key_xxx").then(
        () => alert("Email sent successfully!"),
        (err) => alert("Failed to send email: " + err.text)
      );
    });
  };

  return (
    <div className="p-4 max-w-2xl mx-auto" ref={contractRef}>
      <h1 className="text-xl font-bold mb-4">Contract for {clients[clientId].name}</h1>
      <p className="mb-4">Invoice Number: {invoiceId}</p>
      <p className="mb-6">
        This contract is between <strong>Keller Williams Realty</strong> and <strong>{clients[clientId].name}</strong>.
      </p>
      <h2 className="font-semibold mb-2">Sign Below:</h2>
      <canvas
        ref={canvasRef}
        width={500}
        height={150}
        className="border mb-4"
        onMouseDown={startDrawing}
        onMouseMove={draw}
        onMouseUp={endDrawing}
        onMouseLeave={endDrawing}
      />
      <div className="flex gap-2">
        <button className="bg-green-600 text-white px-4 py-2 rounded" onClick={saveSignature}>
          Save Signature
        </button>
        <button className="bg-gray-600 text-white px-4 py-2 rounded" onClick={exportPDF}>
          Export PDF
        </button>
        <button className="bg-blue-600 text-white px-4 py-2 rounded" onClick={sendEmail}>
          Send by Email
        </button>
      </div>
    </div>
  );
}
