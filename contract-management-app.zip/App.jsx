import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Admin from "./pages/Admin";
import Contract from "./pages/Contract";
import ContractsList from "./pages/ContractsList";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Admin />} />
        <Route path="/contract/:clientId/:invoiceId" element={<Contract />} />
        <Route path="/contracts" element={<ContractsList />} />
      </Routes>
    </Router>
  );
}
